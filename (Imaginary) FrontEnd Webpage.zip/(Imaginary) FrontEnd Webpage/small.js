/* ovo je JS kod za all products webpage html */

/*form js*/
document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    //sending msg
    alert(`Thank you, ${name}! Your message has been sent.`);

    //resets form fields
    document.getElementById('contact-form').reset();
});

//handls dropdown menus
document.querySelectorAll('.dropdown > a').forEach(function(dropdownLink) {
    dropdownLink.addEventListener('click', function(event) {
        event.preventDefault();
        const dropdownMenu = this.nextElementSibling;
        dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
        this.querySelector('::after').style.transform = dropdownMenu.style.display === 'block' ? 'rotate(180deg)' : 'rotate(0deg)';
    });
});

document.addEventListener('click', function(event) {
    document.querySelectorAll('.dropdown-menu').forEach(function(dropdownMenu) {
        if (!dropdownMenu.parentElement.contains(event.target)) {
            dropdownMenu.style.display = 'none';
            dropdownMenu.previousElementSibling.querySelector('::after').style.transform = 'rotate(0deg)';
        }
    });
});

window.addEventListener('scroll', function() {
    const navbar = document.querySelector('nav');
    const heroSection = document.querySelector('.hero');
    console.log('Scroll event detected');
    if (window.scrollY > heroSection.offsetHeight) {
        console.log('Adding scrolled class');
        navbar.classList.add('scrolled');
    } else {
        console.log('Removing scrolled class');
        navbar.classList.remove('scrolled');
    }
});

// Modal functionality
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('product-modal');
    const closeModal = document.getElementById('close-modal');
    const productImages = document.querySelectorAll('.item img');

    productImages.forEach(image => {
        image.addEventListener('click', () => {
            
            const productDescription = image.alt + " - Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.";
            const productImageSrc = image.src;
            const woodType = "Oak"; 
            const dimensions = "10x5x2 cm"; 
            const otherDetails = "Perfect for small spaces.";

            const productDetails = `Type of Wood: ${woodType}. Dimensions: ${dimensions}. Other Details: ${otherDetails}.`;

            document.getElementById('product-description').textContent = productDescription;
            document.getElementById('product-image').src = productImageSrc;
            document.getElementById('product-details').textContent = productDetails;

            //shows the modal
            modal.classList.remove('hidden');
        });
    });

    closeModal.addEventListener('click', () => {
        //hides the modal
        modal.classList.add('hidden');
    });
});

//array of product details
const products = [
    {
        id: 'product1',
        name: "Small Board 'Oak-DARK'",
        image: '333.jpg',
        woodType: 'Oak',
        dimensions: '10x5x2 inches',
        otherDetails: 'Perfect for small spaces.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product2',
        name: "Small Board 'Cherry-LIGHT'",
        image: '66.jpg',
        woodType: 'Cherry',
        dimensions: '12x6x2 inches',
        otherDetails: 'Ideal for kitchen use.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product3',
        name: "Small Board 'Cherry-DARK'",
        image: '77.jpg',
        woodType: 'Cherry',
        dimensions: '12x6x2 inches',
        otherDetails: 'Ideal for kitchen use.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product4',
        name: "Small Board 'Oak-LIGHT'",
        image: '444.jpg',
        woodType: 'Oak',
        dimensions: '10x5x2 inches',
        otherDetails: 'Perfect for small spaces.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product5',
        name: "Small Board 'Walnut-MIX'",
        image: '666.jpg',
        woodType: 'Walnut',
        dimensions: '11x5x2 inches',
        otherDetails: 'Unique and stylish.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product6',
        name: "Small Board 'Walnut-MIX'",
        image: '55.jpg',
        woodType: 'Walnut',
        dimensions: '11x5x2 inches',
        otherDetails: 'Unique and stylish.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product7',
        name: "Small Board 'Walnut-MIX'",
        image: '88.jpg',
        woodType: 'Walnut',
        dimensions: '11x5x2 inches',
        otherDetails: 'Unique and stylish.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product8',
        name: "Small Board 'Walnut-MIX'",
        image: '99.jpg',
        woodType: 'Walnut',
        dimensions: '11x5x2 inches',
        otherDetails: 'Unique and stylish.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product9',
        name: "Small Board 'Walnut-MIX'",
        image: '111.jpg',
        woodType: 'Walnut',
        dimensions: '11x5x2 inches',
        otherDetails: 'Unique and stylish.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product10',
        name: "Small Board 'Walnut-MIX'",
        image: '777.jpg',
        woodType: 'Walnut',
        dimensions: '11x5x2 inches',
        otherDetails: 'Unique and stylish.',
        description: 'Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.'
    }
];

//modal functionality
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('product-modal');
    const closeModal = document.getElementById('close-modal');
    const productImages = document.querySelectorAll('.item img');
    const shopNowButton = document.getElementById('shop-now');
    const contactSection = document.getElementById('contact');

    productImages.forEach(image => {
        image.addEventListener('click', () => {
            const productId = image.getAttribute('data-id');
            const product = products.find(p => p.id === productId);

            if (product) {
                document.getElementById('product-description').textContent = product.description;
                document.getElementById('product-image').src = product.image;
                document.getElementById('product-details').textContent = `Type of Wood: ${product.woodType}. Dimensions: ${product.dimensions}. Other Details: ${product.otherDetails}.`;

                
                const productImage = document.getElementById('product-image');
                productImage.style.width = '500px';
                productImage.style.height = 'auto';

                //shows the modal
                modal.classList.remove('hidden');
            }
        });
    });

    closeModal.addEventListener('click', () => {
        //hides the modal
        modal.classList.add('hidden');
    });

    //Shop Now button
    shopNowButton.addEventListener('click', () => {
        
        contactSection.scrollIntoView({ behavior: 'smooth' });
        
        modal.classList.add('hidden');
    });
});