/* ovo je JS kod za all products webpage html */

document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Here you can add code to send the form data to your server or email service
    alert(`Thank you, ${name}! Your message has been sent.`);

    // Reset the form fields
    document.getElementById('contact-form').reset();
});

// Handle dropdown menus
document.querySelectorAll('.dropdown > a').forEach(function(dropdownLink) {
    dropdownLink.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default link behavior
        const dropdownMenu = this.nextElementSibling;
        dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
        this.querySelector('::after').style.transform = dropdownMenu.style.display === 'block' ? 'rotate(180deg)' : 'rotate(0deg)';
    });
});

document.addEventListener('click', function(event) {
    document.querySelectorAll('.dropdown-menu').forEach(function(dropdownMenu) {
        if (!dropdownMenu.parentElement.contains(event.target)) {
            dropdownMenu.style.display = 'none';
            dropdownMenu.previousElementSibling.querySelector('::after').style.transform = 'rotate(0deg)';
        }
    });
});

window.addEventListener('scroll', function() {
    const navbar = document.querySelector('nav');
    const heroSection = document.querySelector('.hero');
    console.log('Scroll event detected'); // Debugging statement
    if (window.scrollY > heroSection.offsetHeight) {
        console.log('Adding scrolled class'); // Debugging statement
        navbar.classList.add('scrolled');
    } else {
        console.log('Removing scrolled class'); // Debugging statement
        navbar.classList.remove('scrolled');
    }
});

// Modal functionality
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('product-modal');
    const closeModal = document.getElementById('close-modal');
    const productImages = document.querySelectorAll('.item img');

    productImages.forEach(image => {
        image.addEventListener('click', () => {
            // Update modal content based on the clicked image
            const productDescription = image.alt + " - Handcrafted from the finest quality wood, our small-sized products are designed to bring both elegance and functionality to your home.";
            const productImageSrc = image.src;
            const woodType = "Oak"; // Placeholder, update with actual data
            const dimensions = "10x5x2 inches"; // Placeholder, update with actual data
            const otherDetails = "Perfect for small spaces."; // Placeholder, update with actual data

            const productDetails = `Type of Wood: ${woodType}. Dimensions: ${dimensions}. Other Details: ${otherDetails}.`;

            document.getElementById('product-description').textContent = productDescription;
            document.getElementById('product-image').src = productImageSrc;
            document.getElementById('product-details').textContent = productDetails;

            // Show the modal
            modal.classList.remove('hidden');
        });
    });

    closeModal.addEventListener('click', () => {
        // Hide the modal
        modal.classList.add('hidden');
    });
});

// Array of product details
const products = [
    {
        id: 'product1',
        name: "Large Board 'Cherry-MIX'",
        image: '9999.jpg',
        woodType: 'Cherry',
        dimensions: '20x10x2 inches',
        otherDetails: 'Perfect for large spaces.',
        description: 'Handcrafted from the finest quality wood, our large-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product2',
        name: "Large Board 'Birch-MIX'",
        image: '11111.jpg',
        woodType: 'Birch',
        dimensions: '22x11x2 inches',
        otherDetails: 'Ideal for kitchen use.',
        description: 'Handcrafted from the finest quality wood, our large-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product3',
        name: "Large Board 'Cherry-MIX'",
        image: '22222.jpg',
        woodType: 'Cherry',
        dimensions: '22x11x2 inches',
        otherDetails: 'Ideal for kitchen use.',
        description: 'Handcrafted from the finest quality wood, our large-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product4',
        name: "Large Boards 'MIX'",
        image: '7777.jpg',
        woodType: 'Mixed',
        dimensions: '24x12x2 inches',
        otherDetails: 'Unique and stylish.',
        description: 'Handcrafted from the finest quality wood, our large-sized products are designed to bring both elegance and functionality to your home.'
    },
    {
        id: 'product5',
        name: "Large Boards 'MIX'",
        image: '6666.jpg',
        woodType: 'Mixed',
        dimensions: '24x12x2 inches',
        otherDetails: 'Unique and stylish.',
        description: 'Handcrafted from the finest quality wood, our large-sized products are designed to bring both elegance and functionality to your home.'
    }
];

// Modal functionality
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('product-modal');
    const closeModal = document.getElementById('close-modal');
    const productImages = document.querySelectorAll('.item img');
    const shopNowButton = document.getElementById('shop-now');
    const contactSection = document.getElementById('contact');

    productImages.forEach(image => {
        image.addEventListener('click', () => {
            const productId = image.getAttribute('data-id');
            const product = products.find(p => p.id === productId);

            if (product) {
                document.getElementById('product-description').textContent = product.description;
                document.getElementById('product-image').src = product.image;
                document.getElementById('product-details').textContent = `Type of Wood: ${product.woodType}. Dimensions: ${product.dimensions}. Other Details: ${product.otherDetails}.`;

                // Set the size directly
                const productImage = document.getElementById('product-image');
                productImage.style.width = '500px'; // Adjust the width as needed
                productImage.style.height = 'auto'; // Maintain aspect ratio

                // Show the modal
                modal.classList.remove('hidden');
            }
        });
    });

    closeModal.addEventListener('click', () => {
        // Hide the modal
        modal.classList.add('hidden');
    });

    // Add event listener for the Shop Now button
    shopNowButton.addEventListener('click', () => {
        // Scroll to the contact section
        contactSection.scrollIntoView({ behavior: 'smooth' });
        // Hide the modal
        modal.classList.add('hidden');
    });
});